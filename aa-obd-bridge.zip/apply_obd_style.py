#!/usr/bin/env python3
"""Экран «Подключение к OBD» берёт тему приложения: убираем свою тему из манифеста.
Запускать из корня репозитория: python3 apply_obd_style.py"""
import re, sys

path = 'app/src/main/AndroidManifest.xml'
try:
    text = open(path, encoding='utf-8').read()
except FileNotFoundError:
    print('ОШИБКА: нет ' + path + ' (запускайте из корня репозитория)'); sys.exit(1)

tag = re.compile(r'<activity\b[^>]*?com\.aatorque\.obd\.ObdSettingsActivity[^>]*>', re.S)
m = tag.search(text)
if not m:
    print('ОШИБКА: в манифесте нет ObdSettingsActivity'); sys.exit(1)
new_tag = re.sub(r'\s*android:theme="[^"]*"', '', m.group(0))
if new_tag == m.group(0):
    print('Своей темы у экрана нет — менять нечего.')
else:
    open(path, 'w', encoding='utf-8', newline='\n').write(text[:m.start()] + new_tag + text[m.end():])
    print('тема экрана убрана из манифеста')
print('Готово.')
