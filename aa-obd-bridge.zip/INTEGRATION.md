# Подключение модуля ELM327 к форку AA Torque

Модуль подменяет Torque Pro: форк привязывается к `ObdBridgeService` вместо Torque,
экран и настройки остаются прежними. Код не компилировался (в моей среде нет Kotlin),
первая сборка у вас в Android Studio или в GitHub Actions.

## Шаги
1. Скопируйте `src/com/aatorque/obd/*.kt` в `app/src/main/java/com/aatorque/obd/`.
2. AIDL (`ITorqueService.aidl`) в репозитории не меняйте: привязка работает с любым набором его методов.
3. `AndroidManifest.xml`: добавьте разрешения и сервис
   ```xml
   <uses-permission android:name="android.permission.BLUETOOTH_CONNECT"/>
   <uses-permission android:name="android.permission.BLUETOOTH" android:maxSdkVersion="30"/>
   <uses-permission android:name="android.permission.FOREGROUND_SERVICE"/>
   <uses-permission android:name="android.permission.FOREGROUND_SERVICE_CONNECTED_DEVICE"/>
   <uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>
   <service android:name="com.aatorque.obd.ObdBridgeService"
            android:exported="false"
            android:foregroundServiceType="connectedDevice"/>
   ```
4. В `SettingsActivity.onCreate` (экран приложения, запуск пользователем всегда разрешён):
   запросите в рантайме `BLUETOOTH_CONNECT` и `POST_NOTIFICATIONS` (Android 12/13+) и вызовите
   `com.aatorque.obd.ObdBridgeService.start(this)`. Это запускает сервис как foreground.
5. Подмена привязки: замените в репозитории два файла (в `app/src/main/java/com/aatorque/stats/`)
   на `TorqueService.kt` и `TorqueServiceWrapper.kt` из папки patched. В каждом заменён Intent на Torque
   на `Intent(..., ObdBridgeService::class.java)`, добавлен import и вызов `ObdBridgeService.start(...)`.
   Затем выполните в терминале `grep -rn "org.prowl.torque" app/src` и проверьте оставшиеся упоминания
   (проверки «Torque установлен» или запуск приложения Torque могут мешать).
6. Адаптер: по умолчанию берётся первый сопряжённый с именем вида OBD/ELM/V-Link и т.п. Точный адрес
   нужен только при нескольких похожих устройствах: впишите его в `ObdConfig.ADAPTER_MAC`.
7. Процент заполнения DPF: впишите порог сажи (г/л) в `ObdConfig.DPF_FULL_GL`. Пока он 0.0,
   «DPF %» показывает пустое значение, а «Накопление сажи» в г/л работает всегда.

## Меню подключения (ObdSettingsActivity)
Добавьте в манифест внутрь `<application>` (рядом с сервисом):
```xml
<activity
    android:name="com.aatorque.obd.ObdSettingsActivity"
    android:label="OBD подключение"
    android:icon="@android:drawable/stat_sys_data_bluetooth"
    android:exported="true"
    android:theme="@android:style/Theme.DeviceDefault.Light.DarkActionBar">
    <intent-filter>
        <action android:name="android.intent.action.MAIN"/>
        <category android:name="android.intent.category.LAUNCHER"/>
    </intent-filter>
</activity>
```
Появится второй значок «OBD подключение». На экране: состояние связи, выбор адаптера из сопряжённых,
запуск/остановка, порог сажи для «DPF %» и проверка значений без Android Auto.
Нажатие на уведомление сервиса тоже открывает этот экран.

## Foreground-режим
- Сервис показывает постоянное уведомление со статусом («Подключено», «Связь потеряна»…) и кнопкой «Остановить».
- Сервис, запущенный из фона (например, когда телефон сам подключился к машине), на Android 12+ может
  не получить права стать foreground: система это запрещает. Исключение гасится, сервис работает как
  обычный привязанный. Чтобы он гарантированно держался в фоне, откройте приложение один раз перед поездкой.
- Для Samsung дополнительно: Настройки → Приложения → AA Torque → Батарея → «Без ограничений»,
  и добавьте приложение в «Никогда не спящие» (Обслуживание устройства → Батарея → Фоновые ограничения).
- Сервис живёт до нажатия «Остановить» в уведомлении или принудительной остановки приложения.

## Что проверить при первом запуске
- Формат строки `getPIDInformation`: «Название,Кратко,Единицы,Максимум,Минимум,Масштаб».
  Форк сортирует список по первому полю (названию). Остальные поля читает экран выбора параметров;
  если там будут пустые подписи, пришлите `SettingsPIDFragment.kt`.
- ID параметров `ff9001…ff9012` выбраны hex-подобными. Если форк разбирает ID как число, это сработает.
- Чтение ошибок (DTC) в модуль не входит, как договорились.
