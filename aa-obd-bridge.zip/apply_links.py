#!/usr/bin/env python3
"""Подключение по BLE и Wi-Fi: разрешения в манифесте и описание в README.
Запускать из корня репозитория: python3 apply_links.py"""
import os, re, sys

def die(msg):
    print('ОШИБКА:', msg); sys.exit(1)

def write(path, text):
    open(path, 'w', encoding='utf-8', newline='\n').write(text); print('записан', path)

# ---------- 1. манифест ----------
mf = 'app/src/main/AndroidManifest.xml'
if not os.path.exists(mf): die('нет ' + mf + ' (запускайте из корня репозитория)')
t = open(mf, encoding='utf-8').read()
want = [
    ('android.permission.BLUETOOTH_SCAN',
     '<uses-permission android:name="android.permission.BLUETOOTH_SCAN" android:usesPermissionFlags="neverForLocation"/>'),
    ('android.permission.ACCESS_FINE_LOCATION',
     '<uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" android:maxSdkVersion="30"/>'),
    ('android.permission.ACCESS_NETWORK_STATE', '<uses-permission android:name="android.permission.ACCESS_NETWORK_STATE"/>'),
    ('android.permission.CHANGE_NETWORK_STATE', '<uses-permission android:name="android.permission.CHANGE_NETWORK_STATE"/>'),
    ('android.hardware.bluetooth_le',
     '<uses-feature android:name="android.hardware.bluetooth_le" android:required="false"/>'),
]
add = [line for name, line in want if name not in t]
if add:
    m = re.search(r'^([ \t]*)<application\b', t, re.M)
    if not m: die('в манифесте нет <application')
    ind = m.group(1)
    block = ''.join(ind + line + '\n' for line in add)
    write(mf, t[:m.start()] + block + t[m.start():])
    print('добавлено в манифест:', len(add))
else:
    print('манифест уже содержит нужные разрешения')

# ---------- 2. README ----------
MARK = '<!-- link-types -->'
SECTION = MARK + '''
## Типы подключения

Тип выбирается в «Подключение к OBD → Тип подключения».
- **Bluetooth Classic** (по умолчанию): адаптер сопряжён в настройках Bluetooth телефона, выбирается в списке «Адаптер».
- **Bluetooth LE (BLE):** нажмите «Найти BLE-адаптеры», выберите адаптер из списка. Поддерживаются типовые адаптеры (службы FFF0, FFE0, 18F0, Nordic UART), остальные определяются автоматически. BLE обычно медленнее Classic.
- **Wi-Fi:** подключите телефон к сети адаптера (имя вроде `WiFi_OBDII` или `V-LINK`), по умолчанию адрес `192.168.0.10`, порт `35000`. Приложение работает именно через сеть адаптера, мобильный интернет остаётся доступным. На Samsung отключите автопереключение на мобильные данные, иначе телефон может отключаться от сети без интернета. Wi-Fi-адаптер подходит только для проводного Android Auto: при беспроводном Wi-Fi телефона занят связью с магнитолой.

Подключение по BLE и Wi-Fi написано по стандартным схемам адаптеров и проверено не на всех моделях. О проблемах сообщайте через «⋮ → Сообщить об ошибке».

'''
if os.path.exists('README.md'):
    r = open('README.md', encoding='utf-8').read()
    old_limit = re.compile(r'^- Только ELM327 по \*\*Bluetooth Classic\*\*[^\n]*$', re.M)
    new_limit = '- ELM327 по **Bluetooth Classic**, **BLE** и **Wi-Fi** (BLE и Wi-Fi проверены не на всех моделях адаптеров).'
    r2 = old_limit.sub(new_limit, r)
    if MARK in r2:
        r2 = re.sub(re.escape(MARK) + r'\n## Типы подключения.*?(?=\n## )', lambda m: SECTION.rstrip('\n') + '\n', r2, count=1, flags=re.S)
    elif '## Процент заполнения' in r2:
        r2 = r2.replace('## Процент заполнения', SECTION + '## Процент заполнения', 1)
    elif '## Ограничения' in r2:
        r2 = r2.replace('## Ограничения', SECTION + '## Ограничения', 1)
    else:
        r2 = r2.rstrip('\n') + '\n\n' + SECTION
    if r2 != r:
        write('README.md', r2)
    else:
        print('README уже актуален')
print('Готово.')
