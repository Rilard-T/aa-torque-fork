#!/usr/bin/env python3
"""Убирает все упоминания Mazda Diesel из текстов проекта и показывает, что осталось.
Запускать из корня репозитория: python3 apply_remove_md.py"""
import os, re, sys

RULES = [
    (r'\s*\(как в Mazda Diesel\)', ''),
    (r',\s*как в Mazda Diesel', ''),
    (r',\s*Mazda Diesel', ''),
    (r'Mazda Diesel,\s*', ''),
    (r'\s*как в Mazda Diesel', ''),
]
LEFT = re.compile(r'mazda[\s_\-]*diesel|SkyD\b', re.I)
EXT = ('.kt', '.java', '.xml', '.md', '.yml', '.yaml', '.gradle', '.kts', '.py', '.txt', '.pro', '.json')
SKIP_DIRS = {'.git', 'build', '.gradle', 'node_modules', '.idea'}

changed, left, files_named = [], [], []
for root, dirs, files in os.walk('.'):
    dirs[:] = [d for d in dirs if d not in SKIP_DIRS]
    for fn in files:
        path = os.path.join(root, fn)
        if LEFT.search(fn):
            files_named.append(path)
        if not fn.endswith(EXT) or fn == 'apply_remove_md.py':
            continue
        try:
            text = open(path, encoding='utf-8').read()
        except (UnicodeDecodeError, OSError):
            continue
        new = text
        for pat, rep in RULES:
            new = re.sub(pat, rep, new)
        if new != text:
            open(path, 'w', encoding='utf-8', newline='\n').write(new)
            changed.append(path)
        for i, line in enumerate(new.splitlines(), 1):
            if LEFT.search(line):
                left.append('%s:%d: %s' % (path, i, line.strip()[:120]))

print('изменено файлов:', len(changed))
for p in changed: print('  ', p)
if left:
    print('\nОсталось упоминаний (поправьте вручную или пришлите мне):')
    for l in left: print('  ', l)
if files_named:
    print('\nФайлы с таким именем (удалите: git rm "<путь>"):')
    for f in files_named: print('  ', f)
if not left and not files_named:
    print('\nУпоминаний Mazda Diesel не осталось.')
print('Готово.')
